<template>
  <div class="main-content my-content">
    <div class="page-header">
      <h3 class="page-title"></h3>
     
      <div class="page-actions">
       
      </div>
    </div>
    <div class="">
      <div class="col-sm-12">
        <div class="">
          
          
           <p>{{form.title_english}}</p>
           <p v-html="form.page_html_content"></p>
           
         
        </div>
      </div>
    </div>
  </div>
</template>
<script type="text/babel">
import SiteHeader from "../../layouts/partials/TheSiteHeader.vue";
import SiteFooter from "../../layouts/partials/TheSiteFooter.vue";
import SiteSidebar from "../../layouts/partials/TheSiteSidebar.vue";
import { VueEditor } from "vue2-editor";
import { TableComponent, TableColumn } from "vue-table-component";


export default {
  data() {
    return {
      form: {
        page_html_content: "",
        title_english: ""
      }
    };
  },
  mounted() {
    this.$utils.setLayout("default");
    this.getCms();
  },
  components: {
    TableComponent,
    TableColumn,
    SiteHeader,
    SiteFooter,
    VueEditor
  },

  methods: {
    async getCms() {
      try {
                  window.toastr["info"]("  - Title <br>  - HTML Content", "CMS VIEW");

        let testSlug = this.$route.params.testSlug;
// alert(testSlug)
        const response = await axios.get(
          `/api/slugGet/get/` + testSlug
        );
        this.form.title_english = response.data[0].title_english;
        this.form.page_html_content = response.data[0].page_html_content;
      } catch (error) {
        if (error) {
          window.toastr["error"]("There was an error", "Error");
        }
      }
    }
  }
};
</script>
