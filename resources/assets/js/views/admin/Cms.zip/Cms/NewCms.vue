<template>
    <div class="main-content">
        <div class="page-header">
            <h3 class="page-title">Add New CMS Page</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><router-link to="/dashboard"><a>Home</a></router-link></li>
                <li class="breadcrumb-item"><router-link to="/cms"><a>CMS</a></router-link></li>
                <li class="breadcrumb-item active">New CMS Page</li>
            </ol>
        </div>
                <div class="card">
                    <!-- <div class="card-header">
                        <h6>Required Information</h6>
                    </div> -->
                    <div class="card-body">
                        <form  v-on:submit.prevent="submit">

                            <div class="form-row">
                                <div class="form-group col-md-12">
                                    <div class="form-group">
                                        <label for="inputTitle">Title</label>
                                        <input
                                               id="inputTitle"
                                               type="text"
                                               class="form-control"
                                               placeholder="CMS Title"
                                               v-model.trim="form.title_english">
                                    </div>

                                      <div class="form-group">
                                        <label for="inputTitle">Page Content</label>
                                        <template>
                                            <div id="app">
                                                <vue-editor v-model.trim="form.page_html_content"></vue-editor>
                                            </div>
                                        </template>
                                    </div>

                                        <div class="col form-group">
                                           </div>
                                       
  
                                    <div class="form-row">
                                        <div class="col form-group">
                                            <label for="inputKeywords">Keywords (Tags)</label>                                            
                                                   <template>
                                                    <div>
                                                        <vue-tags-input                                                    
                                                        :tags="form.keywords"
                                                        @tags-changed="newTags => form.keywords = newTags"
                                                        v-model.trim="form.tag"
                                                        />
                                                    </div>
                                                   </template>
                                        </div>    
                                        </div> 
                                   
                                     <div class="form-row">
                                        <div class="col form-group">
                                            <label for="inputSlug">Slug</label>
                                            <input
                                                   id="inputSlug"
                                                   type="text"
                                                   class="form-control"
                                                   placeholder="Slug"
                                                   v-model.trim="form.slug">
                                        </div>
                                        
                                    </div>
                                   <div class="form-row">
                                    <div class="col form-group">
                                            <label for="inputDescription">Description</label>
                                            <input
                                                   id="inputDescription"
                                                   type="message"
                                                   class="form-control"
                                                   placeholder="Description"
                                                   v-model.trim="form.description"
                                                   >
                                        </div>
                                     </div>
                                    <div class="form-row">
                                        <div class="form-group col">
                                             <b-form-group label="Select Status">
                                                    <b-form-radio-group id="radios1" v-model.trim="form.selected" :options="options" name="radioOpenions">
                                                    </b-form-radio-group>
                                                    </b-form-group>

                                                    <b-form-group label="">
                                                    <b-form-radio-group id="radios2" v-model.trim="form.selected" name="radioSubComponent">
                                                        <b-form-radio value="1">Active</b-form-radio>
                                                        <b-form-radio value="2">Inactive</b-form-radio>                                                       
                                                    </b-form-radio-group>
                                                    </b-form-group>
                                        </div>
                                       
                                    </div>
                                  
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary" :disabled="$v.form.$invalid" >{{form.submitBtn}}</button>
                            <b-button type=button @click.prevent="cancel" >Cancel</b-button>
                        </form>
                    </div>
                </div> <!--card-->
    </div>
</template>
<script src="https://unpkg.com/@johmun/vue-tags-input/dist/vue-tags-input.js"></script>
<script type="text/babel">
import { required, sameAs, minLength, between } from "vuelidate/lib/validators";
import Multiselect from 'vue-multiselect';
import { VueEditor } from "vue2-editor";
import VueTagsInput from '@johmun/vue-tags-input';
// Advanced Use - Hook into Quill's API for Custom Functionality


export default {
    components: {
      VueEditor,
      VueTagsInput,
   },
  data() {
    return {        
       form: {
        tag: '',
        keywords: [],
        page_html_content: "",
        description: "",
        title_english: "",
        slug: "",
        submitBtn: "Submit",
        selected: "",
      options: [
        { text: 'Active', value: '1' },
        { text: 'Inactive', value: '2' },
        ],
        
      }
    };
  },
  validations: {
   form: {
      slug: {},      
     
    }
  },
  methods: {
      async submit() {
        this.$v.form.$touch();
        if(this.$v.form.$error) return;
        try {
        let response = await window.axios.post('/api/auth/add', { 
            data: this.form,
            status: this.form.value
            });
        window.toastr['success'](response.data.ResponseHeader.ResponseMessage, 'Success')
        this.$router.push('/Cms')
        } catch (error) {
        if (error) {
          window.toastr['error'](response.data.ResponseHeader.ResponseMessage, 'Error')
        }
      }
      },
      async cancel()
      {
           this.$router.push('/Cms')
      },
      
    }
};
</script>
